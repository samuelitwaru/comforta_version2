class EditorManager {
  constructor(editor) {
    this.editor = editor;
    this.selectedTemplateWrapper = null;
    this.selectedComponent = null;
    this.templateComponent = null;
    this.isResizing = false;
    this.currentResizer = null;
    this.initialX = null;
    this.initialWidth = null;
    this.pageId = this.getCurrentPageId();
    this.pageName = "Home";

    this.toolsSection = new ToolBoxManager();
  }

  init() {
    this.editor.on("load", () => {
      if (this.pageId === null) {
        const existingFrame = this.editor
          .getWrapper()
          .find("#frame-container")[0];
        if (!existingFrame) {
          this.initialTemplate();
        }
      } else {
        const projectData = localStorage.getItem(
          `page-${this.getCurrentPageId()}`
        );

        if (projectData) {
          try {
            let parsedData = JSON.parse(projectData);

            if (!parsedData.pages) {
              parsedData = {
                pages: [
                  {
                    component: parsedData,
                    frames: [
                      {
                        component: parsedData,
                      },
                    ],
                  },
                ],
              };
            }

            this.editor.loadProjectData(parsedData);
          } catch (error) {
            console.log("Error loading data:" + error);
            const message = "Error loading data";
            const status = "error";
            this.toolsSection.displayAlertMessage(message, status);
          }
        } else {
          this.initialTemplate();
        }
      }

      const wrapper = this.editor.getWrapper();

      wrapper.view.el.addEventListener("click", (e) => {
        const button = e.target.closest(".action-button");
        if (!button) return;

        const templateWrapper = button.closest(".template-wrapper");
        if (!templateWrapper) return;

        this.templateComponent = this.editor.Components.getById(
          templateWrapper.id
        );

        if (!this.templateComponent) return;

        if (button.classList.contains("delete-button")) {
          this.deleteTemplate(this.templateComponent);
        } else if (button.classList.contains("add-button-bottom")) {
          this.addTemplateBottom(this.templateComponent);
        } else if (button.classList.contains("add-button-right")) {
          this.addTemplateRight(this.templateComponent);
        }
      });

      wrapper.set({
        selectable: false,
        droppable: false,
        resizable: {
          handles: "e",
        },
      });


      // call right click handler
      this.rightClickEventHandler();
    });

    this.editor.on("component:selected", (component) => {
      this.selectedTemplateWrapper = component.getEl();
      this.selectedComponent = component;

      const sidebarInputTitle = document.getElementById("tile-title");
      if (this.selectedTemplateWrapper) {
        const tileLabel = this.selectedTemplateWrapper.querySelector(
          ".tile-title"
        );
        if (tileLabel) {
          sidebarInputTitle.value = tileLabel.textContent;
        }

        document.querySelector(`#templates-button`).classList.remove("active");
        document.querySelector(`#pages-button`).classList.remove("active");
        document.querySelector(`#pages-button`).classList.add("active");
        document.querySelector(`#mapping-section`).style.display = "none";
        document.querySelector(`#tools-section`).style.display = "block";

        document
          .querySelector(`#templates-content`)
          .classList.remove("active-tab");
        document.querySelector(`#pages-content`).classList.add("active-tab");
      }
    });

    // Listen for component drag start and change the cursor
    this.editor.on("component:drag:start", (component) => {
      const iframe = document.querySelector("#gjs iframe");
      const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
      iframeDoc.body.style.cursor = "grabbing";
    });

    // Listen for component drag end and reset the cursor
    this.editor.on("component:drag:end", (component) => {
      const iframe = document.querySelector("#gjs iframe");
      const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
      iframeDoc.body.style.cursor = "";
    });

    const sidebarInputTitle = document.getElementById("tile-title");

    sidebarInputTitle.addEventListener("input", (e) => {
      this.updateTileTitle(e.target.value);
    });

    const frameEl = this.editor.Canvas.getFrameEl();
    frameEl.contentDocument.addEventListener("mousedown", this.initResize);
    frameEl.contentDocument.addEventListener("mousemove", this.resize);
    frameEl.contentDocument.addEventListener("mouseup", this.stopResize);

    //auto save page every 2 seconds
    setInterval(() => {
      this.saveCurrentPage();
    }, 2000);
  }

  updateTileTitle(inputTitle) {
    if (this.selectedTemplateWrapper) {
      const titleComponent = this.editor.getSelected().find(".tile-title")[0];
      if (titleComponent) {
        titleComponent.components(inputTitle);
        this.editor.getSelected().addAttributes({"tile-title": inputTitle})
      }
    }
  }

  getSelectedTemplateWrapper() {
    return this.selectedTemplateWrapper;
  }

  getSelectedComponent() {
    return this.selectedComponent;
  }

  setCurrentPageId(pageId) {
    localStorage.setItem("pageId", pageId);
  }

  getCurrentPageId() {
    return localStorage.getItem("pageId");
  }

  getCurrentPageName() {
    return this.pageName;
  }

  setCurrentPageName(pageName) {
    this.pageName = pageName;
  }

  addFreshTemplate(template) {
    this.editor.DomComponents.clear();
    let fullTemplate = "";

    template.forEach((columns) => {
      const templateRow = this.generateTemplateRow(columns);
      fullTemplate += templateRow;
    });

    this.editor.addComponents(`
      <div class="frame-container"
           id="frame-container"
           data-gjs-type="template-wrapper"
           data-gjs-draggable="false"
           data-gjs-selectable="false"
           data-gjs-editable="false"
           data-gjs-highlightable="false"
           data-gjs-droppable="false"
           data-gjs-hoverable="false">
        <div class="container-column"
             data-gjs-type="template-wrapper"
             data-gjs-draggable="false"
             data-gjs-selectable="false"
             data-gjs-editable="false"
             data-gjs-highlightable="false"
             data-gjs-droppable="false"
             data-gjs-hoverable="false">
            ${fullTemplate}
        </div>
      </div>
      `);

    
      const message = 'Template added successfully';
      const status = "success";
      this.toolsSection.displayAlertMessage(message, status);
  }

  initialTemplate() {
    return this.editor.addComponents(`
      <div class="frame-container"
           id="frame-container"
           data-gjs-type="template-wrapper"
           data-gjs-draggable="false"
           data-gjs-selectable="false"
           data-gjs-editable="false"
           data-gjs-highlightable="false"
           data-gjs-droppable="false"
           data-gjs-hoverable="false">
        <div class="container-column"
             data-gjs-type="template-wrapper"
             data-gjs-draggable="false"
             data-gjs-selectable="false"
             data-gjs-editable="false"
             data-gjs-highlightable="false"
             data-gjs-droppable="false"
             data-gjs-hoverable="false">
          <div class="container-row"
               data-gjs-type="template-wrapper"
               data-gjs-draggable="false"
               data-gjs-selectable="false"
               data-gjs-editable="false"
               data-gjs-highlightable="true"
               data-gjs-hoverable="true">
            ${this.createTemplateHTML(true)}
          </div>
        </div>
      </div>
    `)[0];
  }

  createTemplateHTML(isDefault = false) {
    return `
      <div class="template-wrapper ${isDefault ? "default-template" : ""}"
            data-gjs-type="template-wrapper"
            data-gjs-droppable="false">
        <div class="template-block"
             data-gjs-draggable="false"
             data-gjs-selectable="false"
             data-gjs-editable="false"
             data-gjs-highlightable="false"
             data-gjs-droppable="false"
             data-gjs-resizable="false"
             data-gjs-hoverable="false">
            <span 
              id="tile-icon" 
              class="tile-icon"
              data-gjs-draggable="false"
              data-gjs-selectable="false"
              data-gjs-editable="false"
              data-gjs-droppable="false"
              data-gjs-highlightable="false"
              data-gjs-hoverable="false">
              
            </span>
            <span 
              id="tile-title" 
              class="tile-title"
              data-gjs-draggable="false"
              data-gjs-selectable="false"
              data-gjs-editable="false"
              data-gjs-droppable="false"
              data-gjs-highlightable="false"
              data-gjs-hoverable="false">Title</span>
        </div>
        ${
          !isDefault
            ? `
          <button class="action-button delete-button" title="Delete template"
                    data-gjs-draggable="false"
                    data-gjs-selectable="false"
                    data-gjs-editable="false"
                    data-gjs-droppable="false"
                    data-gjs-highlightable="false"
                    data-gjs-hoverable="false">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                    data-gjs-draggable="false"
                    data-gjs-selectable="false"
                    data-gjs-editable="false"
                    data-gjs-editable="false"
                    data-gjs-droppable="false"
                    data-gjs-highlightable="false"
                    data-gjs-hoverable="false">
              <line x1="5" y1="12" x2="19" y2="12" 
                data-gjs-draggable="false"
                data-gjs-selectable="false"
                data-gjs-editable="false"
                data-gjs-highlightable="false"
                data-gjs-droppable="false"
                data-gjs-hoverable="false"/>
            </svg>
          </button>
        `
            : ""
        }
        <button class="action-button add-button-bottom" title="Add template below"
                data-gjs-draggable="false"
                data-gjs-selectable="false"
                data-gjs-droppable="false"
                data-gjs-editable="false"
                data-gjs-highlightable="false"
                data-gjs-hoverable="false">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                data-gjs-draggable="false"
                data-gjs-selectable="false"
                data-gjs-editable="false"
                data-gjs-editable="false"
                data-gjs-droppable="false"
                data-gjs-highlightable="false"
                data-gjs-hoverable="false">
            <line x1="12" y1="5" x2="12" y2="19" 
                data-gjs-draggable="false"
                data-gjs-selectable="false"
                data-gjs-editable="false"
                data-gjs-highlightable="false"
                data-gjs-droppable="false"
                data-gjs-hoverable="false"/>
            <line x1="5" y1="12" x2="19" y2="12" 
                data-gjs-draggable="false"
                data-gjs-selectable="false"
                data-gjs-editable="false"
                data-gjs-highlightable="false"
                data-gjs-droppable="false"
                data-gjs-hoverable="false"/>
          </svg>
        </button>
        <button class="action-button add-button-right" title="Add template right"
                data-gjs-draggable="false"
                data-gjs-selectable="false"
                data-gjs-editable="false"
                data-gjs-droppable="false"
                data-gjs-highlightable="false"
                data-gjs-hoverable="false">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                data-gjs-draggable="false"
                data-gjs-selectable="false"
                data-gjs-editable="false"
                data-gjs-editable="false"
                data-gjs-highlightable="false"
                data-gjs-droppable="false"
                data-gjs-hoverable="false">
            <line x1="12" y1="5" x2="12" y2="19" 
                data-gjs-draggable="false"
                data-gjs-selectable="false"
                data-gjs-editable="false"
                data-gjs-highlightable="false"
                data-gjs-droppable="false"
                data-gjs-hoverable="false"/>
            <line x1="5" y1="12" x2="19" y2="12" 
                data-gjs-draggable="false"
                data-gjs-selectable="false"
                data-gjs-editable="false"
                data-gjs-highlightable="false"
                data-gjs-droppable="false"
                data-gjs-hoverable="false"/>
          </svg>
        </button>
        <div class="resize-handle"
                data-gjs-draggable="false"
                data-gjs-selectable="false"
                data-gjs-editable="false"
                data-gjs-highlightable="false"
                data-gjs-droppable="false"
                data-gjs-hoverable="false">
        </div>
      </div>
    `;
  }

  generateTemplateRow(columns) {
    let columnWidth = 100 / columns;
    if (columns === 1) {
      columnWidth = 100;
    } else if (columns === 2) {
      columnWidth = 49;
    } else if (columns === 3) {
      columnWidth = 32;
    }

    let wrappers = "";

    for (let i = 0; i < columns; i++) {
      wrappers += `
      <div class="template-wrapper"
                style="flex: 0 0 ${columnWidth}%);"
                data-gjs-type="template-wrapper"
                data-gjs-droppable="false">
                <div class="template-block"
                    data-gjs-draggable="false"
                    data-gjs-selectable="false"
                    data-gjs-editable="false"
                    data-gjs-highlightable="false"
                    data-gjs-droppable="false"
                    data-gjs-resizable="false"
                    data-gjs-hoverable="false">
                  <span 
                    id="tile-icon" 
                    class="tile-icon"
                    data-gjs-draggable="false"
                    data-gjs-selectable="false"
                    data-gjs-editable="false"
                    data-gjs-droppable="false"
                    data-gjs-highlightable="false"
                    data-gjs-hoverable="false">
                  </span>
                  <span 
                    id="tile-title" 
                    class="tile-title"
                    data-gjs-draggable="false"
                    data-gjs-selectable="false"
                    data-gjs-editable="false"
                    data-gjs-droppable="false"
                    data-gjs-highlightable="false"
                    data-gjs-hoverable="false">Title</span>
                </div>
                <button class="action-button delete-button" title="Delete template"
                    data-gjs-draggable="false"
                    data-gjs-selectable="false"
                    data-gjs-editable="false"
                    data-gjs-droppable="false"
                    data-gjs-highlightable="false"
                    data-gjs-hoverable="false">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                    data-gjs-draggable="false"
                    data-gjs-selectable="false"
                    data-gjs-editable="false"
                    data-gjs-editable="false"
                    data-gjs-droppable="false"
                    data-gjs-highlightable="false"
                    data-gjs-hoverable="false">
                    <line x1="5" y1="12" x2="19" y2="12" 
                      data-gjs-draggable="false"
                      data-gjs-selectable="false"
                      data-gjs-editable="false"
                      data-gjs-highlightable="false"
                      data-gjs-droppable="false"
                      data-gjs-hoverable="false"/>
                  </svg>
                </button>
                <button class="action-button add-button-bottom" title="Add template below"
                        data-gjs-draggable="false"
                        data-gjs-selectable="false"
                        data-gjs-droppable="false"
                        data-gjs-editable="false"
                        data-gjs-highlightable="false"
                        data-gjs-hoverable="false"
                        >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                        data-gjs-draggable="false"
                        data-gjs-selectable="false"
                        data-gjs-editable="false"
                        data-gjs-editable="false"
                        data-gjs-highlightable="false"
                        data-gjs-droppable="false"
                        data-gjs-hoverable="false">
                    <line x1="12" y1="5" x2="12" y2="19" 
                        data-gjs-draggable="false"
                        data-gjs-selectable="false"
                        data-gjs-editable="false"
                        data-gjs-highlightable="false"
                        data-gjs-droppable="false"
                        data-gjs-hoverable="false"/>
                    <line x1="5" y1="12" x2="19" y2="12" 
                        data-gjs-draggable="false"
                        data-gjs-selectable="false"
                        data-gjs-editable="false"
                        data-gjs-highlightable="false"
                        data-gjs-droppable="false"
                        data-gjs-hoverable="false"/>
                  </svg>
                </button>
                <button class="action-button add-button-right" title="Add template right"
                        data-gjs-draggable="false"
                        data-gjs-selectable="false"
                        data-gjs-editable="false"
                        data-gjs-droppable="false"
                        data-gjs-highlightable="false"
                        data-gjs-hoverable="false">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                        data-gjs-draggable="false"
                        data-gjs-selectable="false"
                        data-gjs-editable="false"
                        data-gjs-editable="false"
                        data-gjs-highlightable="false"
                        data-gjs-droppable="false"
                        data-gjs-hoverable="false">
                    <line x1="12" y1="5" x2="12" y2="19" 
                        data-gjs-draggable="false"
                        data-gjs-selectable="false"
                        data-gjs-editable="false"
                        data-gjs-highlightable="false"
                        data-gjs-droppable="false"
                        data-gjs-hoverable="false"/>
                    <line x1="5" y1="12" x2="19" y2="12" 
                        data-gjs-draggable="false"
                        data-gjs-selectable="false"
                        data-gjs-editable="false"
                        data-gjs-highlightable="false"
                        data-gjs-droppable="false"
                        data-gjs-hoverable="false"/>
                  </svg>
                </button>
                <div class="resize-handle"
                    data-gjs-draggable="false"
                    data-gjs-selectable="false"
                    data-gjs-editable="false"
                    data-gjs-highlightable="false"
                    data-gjs-droppable="false"
                    data-gjs-hoverable="false">
                </div>
            </div>
      `;
    }
    return `
            <div class="container-row"
                data-gjs-type="template-wrapper"
                data-gjs-draggable="false"
                data-gjs-selectable="false"
                data-gjs-editable="false"
                data-gjs-highlightable="true"
                data-gjs-hoverable="true">
              ${wrappers}
          </div>
    `;
  }

  initResize(e) {
    const resizer = e.target.closest(".resize-handle");
    if (!resizer) return;

    const templateWrapper = resizer.closest(".template-wrapper");
    const containerRow = templateWrapper.parentElement;
    if (!containerRow) return;

    const templates = Array.from(containerRow.children).filter((child) => {
      child.classList.contains("template-wrapper");
    });
    if (templates.length === 3) return;

    this.isResizing = true;
    this.currentResizer = resizer;

    this.initialWidth = templateWrapper.offsetWidth;
    this.initialX = e.clientX;
  }

  // resize(e) {
  //   if (!this.isResizing) return;

  //   const templateWrapper = this.currentResizer.closest(".template-wrapper");
  //   const containerRow = templateWrapper.parentElement;

  //   if (!containerRow) return;

  //   const templates = Array.from(containerRow.children).filter((child) => {
  //     return child.classList.contains("template-wrapper");
  //   });

  //   // Stop resizing if there are three templates
  //   if (templates.length === 3) {
  //     this.stopResize();
  //     return;
  //   }

  //   const currentIndex = templates.indexOf(templateWrapper);
  //   const deltaX = e.clientX - this.initialX;
  //   const containerWidth = containerRow.getBoundingClientRect().width;
  //   const gap = parseFloat(getComputedStyle(containerRow).gap);
  //   const availableWidth = containerWidth - gap;

  //   let newWidthPercentage =
  //     ((this.initialWidth + deltaX) / availableWidth) * 100;

  //   const minWidth = 33.33;
  //   const maxWidth = templates.length === 2 ? 7 : 100; // Adjust maximum width for two templates

  //   // Adjust the new width percentage based on the min and max limits
  //   if (newWidthPercentage < minWidth) {
  //     newWidthPercentage = minWidth;
  //   } else if (newWidthPercentage > maxWidth) {
  //     newWidthPercentage = maxWidth;
  //   }

  //   templateWrapper.style.flex = `0 0 calc(${newWidthPercentage}% - 0.35rem)`;

  //   // Automatically resize the other template if there are two templates
  //   if (templates.length === 2) {
  //     const otherTemplate = templates[currentIndex === 0 ? 1 : 0];
  //     let otherNewWidthPercentage = 100 - newWidthPercentage;

  //     // Ensure the other template's width also does not exceed 70%
  //     if (otherNewWidthPercentage > 70) {
  //       otherNewWidthPercentage = 68;
  //     }

  //     otherTemplate.style.flex = `0 0 calc(${otherNewWidthPercentage}% - 0.35rem)`;
  //   }

  //   // Recalculate the bounding rect (optional)
  //   templateWrapper.getBoundingClientRect();
  // }
  resize(e) {
    if (!this.isResizing) return;

    const templateWrapper = this.currentResizer.closest(".template-wrapper");
    const containerRow = templateWrapper.parentElement;

    if (!containerRow) return;

    const templates = Array.from(containerRow.children).filter((child) => {
      return child.classList.contains("template-wrapper");
    });

    // Stop resizing if there are three templates
    if (templates.length === 3) {
      this.stopResize();
      return;
    }

    const currentIndex = templates.indexOf(templateWrapper);
    const deltaX = e.clientX - this.initialX;
    const containerWidth = containerRow.getBoundingClientRect().width;
    const gap = parseFloat(getComputedStyle(containerRow).gap);
    const availableWidth = containerWidth - gap;
    const step = 100;

    // Calculate the current width percentage
    let newWidth = ((this.initialWidth + deltaX) / availableWidth) * 100;

    // Snap to nearest step of 100px
    newWidth = Math.round(newWidth / step) * step;

    const minWidth = step;
    const maxWidth = templates.length === 2 ? step : 100; // Adjust maximum width for two templates

    if (newWidth < minWidth) {
      newWidth = minWidth;
    } else if (newWidth > maxWidth) {
      newWidth = maxWidth;
    }

    templateWrapper.style.flex = `0 0 ${newWidth}px`;

    if (templates.length === 2) {
      const otherTemplate = templates[currentIndex === 0 ? 1 : 0];
      let otherNewWidth = 100 - newWidth;

      otherNewWidth = Math.round(otherNewWidth / step) * step;
      if (otherNewWidth > 200) {
        otherNewWidth = 200;
      }

      otherTemplate.style.flex = `0 0 calc(${otherNewWidth}px + 0.8rem)`;
    }

    templateWrapper.getBoundingClientRect();
  }

  stopResize() {
    this.isResizing = false;
  }

  updateRightButtons(containerRow) {
    if (!containerRow) return;

    const templates = containerRow.components();
    let totalWidth = 0;
    templates.forEach((template) => {
      if (!template || !template.view || !template.view.el) return;

      const rightButton = template.view.el.querySelector(".add-button-right");
      if (!rightButton) return;
      const rightButtonComponent = template.find(".add-button-right")[0];

      if (templates.length >= 3) {
        rightButton.setAttribute("disabled", "true");
        rightButtonComponent.addStyle({ display: "none" });
      } else {
        rightButton.removeAttribute("disabled");
        rightButtonComponent.addStyle({ display: "flex" });
      }
    });
  }

  addTemplateRight(templateComponent) {
    const containerRow = templateComponent.parent();
    if (!containerRow || containerRow.components().length >= 3) return;

    const newComponents = this.editor.addComponents(this.createTemplateHTML());
    const newTemplate = newComponents[0];
    if (!newTemplate) return;

    const index = templateComponent.index();
    containerRow.append(newTemplate, { at: index + 1 });
    const templates = containerRow.components();

    const equalWidth = 100 / templates.length;
    templates.forEach((template) => {
      template.addStyle({
        flex: `0 0 calc(${equalWidth}% - 0.3.5rem)`,
      });
    });

    this.updateRightButtons(containerRow);
  }

  addTemplateBottom(templateComponent) {
    const currentRow = templateComponent.parent();
    const containerColumn = currentRow?.parent();

    if (!containerColumn) return;

    const newRow = editor.addComponents(`
      <div class="container-row"
          data-gjs-type="template-wrapper"
          data-gjs-draggable="false"
          data-gjs-selectable="false"
          data-gjs-editable="false"
          data-gjs-highlightable="false"
          data-gjs-hoverable="false">
        ${this.createTemplateHTML()}
      </div>
    `)[0];

    const index = currentRow.index();
    containerColumn.append(newRow, { at: index + 1 });
  }

  deleteTemplate(templateComponent) {
    if (
      !templateComponent ||
      templateComponent.getClasses().includes("default-template")
    )
      return;

    const containerRow = templateComponent.parent();
    if (!containerRow) return;

    templateComponent.remove();

    // Adjust widths of remaining templates
    const templates = containerRow.components();
    const newWidth = 100 / templates.length;
    templates.forEach((template) => {
      if (template && template.setStyle) {
        template.addStyle({ width: `${newWidth}%` });
      }
    });

    this.updateRightButtons(containerRow);
  }

  saveCurrentPage() {
    const localStorageKey = `page-${this.getCurrentPageId()}`;
    try {
      console.log(this.editor.getHtml())
      const data = this.editor.getProjectData();
      localStorage.setItem(localStorageKey, JSON.stringify(data));
    } catch (error) {
      const message = "Failed to save current page";
      const status = "succuss";
      this.toolsSection.displayAlertMessage(message, status);
    }
  }

  rightClickEventHandler() {
    const iframe = document.querySelector("#gjs iframe");
    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
    const contextMenu = document.getElementById("contextMenu"); 

    document.addEventListener("click", (e) => {
      if (e.target !== contextMenu) {
        contextMenu.style.display = "none";
      }
    });

    iframeDoc.addEventListener("click", (e) => {
      if (e.target !== contextMenu) {
        contextMenu.style.display = "none";
      }
    });

    iframeDoc.addEventListener('contextmenu', (e) => {
      const block = e.target.closest(".template-block");
      if (block) {
        e.preventDefault(); 
    
        const iframeRect = iframe.getBoundingClientRect();
        const x = iframeRect.left + e.clientX;  
        const y = iframeRect.top + e.clientY;   
    
        contextMenu.style.left = x + 'px';
        contextMenu.style.top = y + 'px';
        contextMenu.style.display = "block";
        
        window.currentBlock = block;
        // const component = editor.getWrapper().find(`[data-gjs-type="default"]`).filter(comp => comp.getEl() === block)[0];
        
        // if (component.hasStyle) {
        //   window.currentBlock = block;
        // }
    
      } else {
        contextMenu.style.display = 'none';  
      }
    });
    
    const deleteImage = document.getElementById('delete-bg-image');
    deleteImage.addEventListener('click', () => {
      const blockToDelete = window.currentBlock;
      if (blockToDelete) {
        console.log(blockToDelete); 
        
        const component = editor.getWrapper().find(`[data-gjs-type="default"]`).filter(comp => comp.getEl() === blockToDelete)[0];

        if (component) {
          component.setStyle({
            "background-image": ""
          });
          console.log('Block deleted in GrapesJS:', component);
        } else {
          console.log('Component not found for the block.');
        }

        contextMenu.style.display = "none";
        console.log('deleteImage clicked and block deleted');
      }
    });

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        contextMenu.style.display = "none";
      }
    });

  }
}

class ToolBoxManager {
  constructor(editorManager, themes, icons, templates, mapping) {
    this.editorManager = editorManager;
    this.themes = themes;
    this.icons = icons;
    this.currentTheme = null;
    this.templates = templates;
    this.mappingsItems = mapping;
  }

  init() {
    this.loadTheme();
    this.listThemesInSelectField();
    this.colorPalette();
    this.loadTiles();
    this.loadPageTemplates();
    this.handleFileManager();

    const tabButtons = document.querySelectorAll(".tab-button");
    const tabContents = document.querySelectorAll(".tab-content");
    tabButtons.forEach((button) => {
      button.addEventListener("click", (e) => {
        e.preventDefault()
        tabButtons.forEach((btn) => btn.classList.remove("active"));
        tabContents.forEach((content) =>
          content.classList.remove("active-tab")
        );

        button.classList.add("active");
        document
          .querySelector(`#${button.dataset.tab}-content`)
          .classList.add("active-tab");
      });
    });

    // mapping
    const mappingButton = document.getElementById("open-mapping");
    const mappingSection = document.getElementById("mapping-section");
    const toolsSection = document.getElementById("tools-section");

    mappingButton.addEventListener("click", (e) => {
      e.preventDefault()

      toolsSection.style.display =
        toolsSection.style.display === "none" ? "block" : "none";

      mappingSection.style.display =
        mappingSection.style.display === "block" ? "none" : "block";

      this.loadMappings();
    });

    // alignment
    const leftAlign = document.getElementById("align-left");
    const centerAlign = document.getElementById("align-center");
    const rightAlign = document.getElementById("align-right");

    leftAlign.addEventListener("click", () => {
      if (this.editorManager.selectedTemplateWrapper) {
        const templateBlock = this.editorManager.editor
          .getSelected()
          .find(".tile-title")[0];

        if (templateBlock) {
          templateBlock.setStyle({
            display: "flex",
            "justify-content": "flex-start",
          });
          this.setAttributeToSelected("tile-text-align", "left")
        }
      }
    });

    centerAlign.addEventListener("click", () => {
      if (this.editorManager.selectedTemplateWrapper) {
        const templateBlock = this.editorManager.editor
          .getSelected()
          .find(".tile-title")[0];

        if (templateBlock) {
          templateBlock.setStyle({
            display: "flex",
            "justify-content": "center",
          });
          this.setAttributeToSelected("tile-text-align", "center")
        }
      }
    });

    rightAlign.addEventListener("click", () => {
      if (this.editorManager.selectedTemplateWrapper) {
        const templateBlock = this.editorManager.editor
          .getSelected()
          .find(".tile-title")[0];

        if (templateBlock) {
          templateBlock.setStyle({
            display: "flex",
            "justify-content": "flex-end",
          });
          this.setAttributeToSelected("tile-text-align", "right")
        }
      }
    });

    // open modal

    // apply opacity to a bg image of a selected tile
    const imageOpacity = document.getElementById("bg-opacity");

    imageOpacity.addEventListener("input", (event) => {
      const value = event.target.value;

      // add opacity to selected tile image
      if (this.editorManager.selectedTemplateWrapper) {
        const templateBlock = this.editorManager.editor
          .getSelected()
          .find(".template-block")[0];

        if (templateBlock) {
          templateBlock.addStyle({
            opacity: value / 100,
          });
        }
      }
    });
  }

  listThemesInSelectField() {
    const themeSelect = document.getElementById("theme-select");

    this.themes.forEach((theme) => {
      const option = document.createElement("option");
      option.value = theme.name;
      option.textContent = theme.name;

      themeSelect.appendChild(option);
    });

    themeSelect.addEventListener("change", (e) => {
      const themeName = e.target.value;

      if (this.setTheme(themeName)) {
        this.themeColorPalette(this.currentTheme.colors);
        localStorage.setItem("selectedTheme", themeName);

        const message = "Theme applied successfully";
        const status = "success";
        this.displayAlertMessage(message, status);
      } else {
        const message = "Error applying theme. Please try again";
        const status = "error";
        this.displayAlertMessage(message, status);
      }
    });
  }

  loadTheme() {
    const savedTheme = localStorage.getItem("selectedTheme");
    if (savedTheme) {
      this.setTheme(savedTheme);
    }
  }

  setTheme(themeName) {
    const theme = this.themes.find((theme) => theme.name === themeName);

    if (!theme) {
      return false;
    }

    this.currentTheme = theme;
    this.applyTheme();

    this.themeColorPalette(this.currentTheme.colors);
    localStorage.setItem("selectedTheme", themeName);

    return true;
  }

  applyTheme() {
    const root = document.documentElement;
    const iframe = document.querySelector("#gjs iframe");

    // Set CSS variables from the selected theme
    root.style.setProperty(
      "--primary-color",
      this.currentTheme.colors.primaryColor
    );
    root.style.setProperty(
      "--secondary-color",
      this.currentTheme.colors.secondaryColor
    );
    root.style.setProperty(
      "--background-color",
      this.currentTheme.colors.backgroundColor
    );
    root.style.setProperty("--text-color", this.currentTheme.colors.textColor);
    root.style.setProperty(
      "--button-bg-color",
      this.currentTheme.colors.buttonBgColor
    );
    root.style.setProperty(
      "--button-text-color",
      this.currentTheme.colors.buttonTextColor
    );
    root.style.setProperty(
      "--card-bg-color",
      this.currentTheme.colors.cardBgColor
    );
    root.style.setProperty(
      "--card-text-color",
      this.currentTheme.colors.cardTextColor
    );
    root.style.setProperty(
      "--accent-color",
      this.currentTheme.colors.accentColor
    );
    root.style.setProperty("--font-family", this.currentTheme.fontFamily);

    // Apply this.currentTheme to iframe (canvas editor)
    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
    iframeDoc.body.style.setProperty(
      "--primary-color",
      this.currentTheme.colors.primaryColor
    );
    iframeDoc.body.style.setProperty(
      "--secondary-color",
      this.currentTheme.colors.secondaryColor
    );
    iframeDoc.body.style.setProperty(
      "--background-color",
      this.currentTheme.colors.backgroundColor
    );
    iframeDoc.body.style.setProperty(
      "--text-color",
      this.currentTheme.colors.textColor
    );
    iframeDoc.body.style.setProperty(
      "--button-bg-color",
      this.currentTheme.colors.buttonBgColor
    );
    iframeDoc.body.style.setProperty(
      "--button-text-color",
      this.currentTheme.colors.buttonTextColor
    );
    iframeDoc.body.style.setProperty(
      "--card-bg-color",
      this.currentTheme.colors.cardBgColor
    );
    iframeDoc.body.style.setProperty(
      "--card-text-color",
      this.currentTheme.colors.cardTextColor
    );
    iframeDoc.body.style.setProperty(
      "--accent-color",
      this.currentTheme.colors.accentColor
    );
    iframeDoc.body.style.setProperty(
      "--font-family",
      this.currentTheme.fontFamily
    );
  }

  themeColorPalette(colors) {
    const colorPaletteContainer = document.getElementById(
      "theme-color-palette"
    );
    colorPaletteContainer.innerHTML = "";

    const colorEntries = Object.entries(colors);

    colorEntries.forEach(([colorName, colorValue], index) => {
      // Create the HTML for each color
      const alignItem = document.createElement("div");
      alignItem.className = "color-item";

      const radioInput = document.createElement("input");
      radioInput.type = "radio";
      radioInput.id = `color-${colorName}`;
      radioInput.name = "theme-color";
      radioInput.value = colorName;

      const colorBox = document.createElement("label");
      colorBox.className = "color-box";
      colorBox.setAttribute("for", `color-${colorName}`);
      colorBox.style.backgroundColor = colorValue;

      alignItem.appendChild(radioInput);
      alignItem.appendChild(colorBox);

      colorPaletteContainer.appendChild(alignItem);

      colorBox.onclick = () => {
        this.editorManager.selectedComponent.addStyle({
          "background-color": colorValue,
        });
        this.setAttributeToSelected("tile-bgcolor", colorValue)

      };
    });
  }

  colorPalette() {
    const textColorBoxes = document.querySelectorAll(
      "#text-color-palette .color-box"
    );
    const iconColorBoxes = document.querySelectorAll(
      "#icon-color-palette .color-box"
    );

    const colorValues = {
      color1: "#ffffff",
      color2: "#333333",
    };

    textColorBoxes.forEach((box, index) => {
      const colorKey = Object.keys(colorValues)[index];

      box.style.backgroundColor = colorValues[colorKey];

      box.onclick = () => {
        this.editorManager.selectedComponent.addStyle({
          color: colorValues[colorKey],
        });
      };
    });

    iconColorBoxes.forEach((box, index) => {
      const colorKey = Object.keys(colorValues)[index];

      box.style.backgroundColor = colorValues[colorKey];

      box.onclick = () => {
        if (this.editorManager.selectedTemplateWrapper) {
          const svgIcon = this.editorManager.editor
            .getSelected()
            .find(".tile-icon path")[0];

          if (svgIcon) {
            svgIcon.removeAttributes("fill");
            svgIcon.addAttributes({ fill: colorValues[colorKey] }); // Use the correct color key
          } else {
            const message = "Svg icon not found. Try again";
            const status = "error";
            this.displayAlertMessage(message, status);
          }
        } else {
          const message = "No tile selected. Please select a tile";
          const status = "error";
          this.displayAlertMessage(message, status);
        }
      };
    });
  }

  loadTiles() {
    const tileIcons = document.getElementById("icons-list");

    this.icons.forEach((icon) => {
      const iconItem = document.createElement("div");
      iconItem.classList.add("icon");
      iconItem.innerHTML = `
          ${icon.svg}
          <span class="icon-title">${icon.name}</span>
      `;

      iconItem.onclick = () => {
        if (this.editorManager.selectedTemplateWrapper) {
          const templateBlock = this.editorManager.selectedTemplateWrapper.querySelector(
            ".template-block"
          );

          if (templateBlock) {
            const iconComponent = this.editorManager.editor
              .getSelected()
              .find(".tile-icon")[0];
            if (iconComponent) {
              iconComponent.components(icon.svg);
              this.setAttributeToSelected("tile-icon", icon.svg)
            }
            const titleComponent = this.editorManager.editor
              .getSelected()
              .find(".tile-title")[0];
            if (titleComponent) {
              titleComponent.components(icon.name);

              const sidebarInputTitle = document.getElementById("tile-title");
              if (sidebarInputTitle) {
                sidebarInputTitle.textContent = icon.name;
              }
            }
          } else {
            const message = "No tile selected. Please select a tile";
            const status = "error";
            this.displayAlertMessage(message, status);
          }
        } else {
          const message = "No tile selected. Please select a tile";
          const status = "error";
          this.displayAlertMessage(message, status);
        }
      };

      tileIcons.appendChild(iconItem);
    });
  }

  loadPageTemplates() {
    const pageTemplates = document.getElementById("page-templates");

    this.templates.forEach((template, index) => {
      const blockElement = document.createElement("div");
      blockElement.className = "page-template-wrapper"; // Wrapper class for each template block

      // Create the number element
      const numberElement = document.createElement("div");
      numberElement.className = "page-template-block-number";
      numberElement.textContent = index + 1; // Set the number

      const templateBlock = document.createElement("div");
      templateBlock.className = "page-template-block";
      templateBlock.title = "Click to load template"; //
      templateBlock.innerHTML = `<div>${template.media}</div>`;

      // Prevent the image from being dragged
      templateBlock.querySelector("img").addEventListener("dragstart", (e) => {
        e.preventDefault();
      });

      blockElement.addEventListener("click", () => {
        const popup = this.popupModal();
        document.body.appendChild(popup);
        popup.style.display = "flex";

        const closeButton = popup.querySelector(".close");
        closeButton.onclick = () => {
          popup.style.display = "none";
          document.body.removeChild(popup);
        };

        const cancelBtn = popup.querySelector("#close-popup");
        cancelBtn.onclick = () => {
          popup.style.display = "none";
          document.body.removeChild(popup);
        };

        const acceptBtn = popup.querySelector("#accept-popup");
        acceptBtn.onclick = () => {
          popup.style.display = "none";
          document.body.removeChild(popup);
          this.editorManager.addFreshTemplate(template.content);
        };
      });

      // Append number and template block to the wrapper
      blockElement.appendChild(numberElement);
      blockElement.appendChild(templateBlock);
      pageTemplates.appendChild(blockElement);
    });
  }

  loadMappings() {
    const treeContainer = document.getElementById("tree-container");
    this.clearMappings();
    treeContainer.appendChild(this.createTree(this.mappingsItems, true));
  }

  clearMappings() {
    const treeContainer = document.getElementById("tree-container");
    treeContainer.innerHTML = ""; // Clear previous mappings
  }

  createTree(data, isRoot = false) {
    const ul = document.createElement("ul");
    if (!isRoot) ul.style.display = "block";

    data.forEach((item, index) => {
      const li = document.createElement("li");
      const span = document.createElement("span");
      span.textContent = item.name;
      li.appendChild(span);
      li.className = this.checkActivePage(item.id) ? "selected-page" : "";
      span.title = item.id;

      if (item.children && item.children.length > 0) {
        const childrenContainer = this.createTree(item.children); // Recursively create children
        li.appendChild(childrenContainer);

        span.textContent = item.name + " +";
        span.style.cursor = "pointer";

        span.onclick = () => {
          childrenContainer.style.display =
            childrenContainer.style.display === "none" ? "block" : "none";

          span.textContent =
            childrenContainer.style.display === "none"
              ? item.name + " +"
              : item.name + " -";
        };
      } else {
        span.onclick = () => {
          this.editorManager.setCurrentPageName(item.name);
          this.editorManager.setCurrentPageId(item.id);

          const editor = this.editorManager.editor;

          editor.DomComponents.clear();
          this.editorManager.templateComponent = null;
          editor.trigger("load");

          document.querySelectorAll(".selected-page").forEach((el) => {
            el.classList.remove("selected-page");
          });

          span.closest("li").classList.add("selected-page");
          const mainPage = document.getElementById("current-page-title");
          mainPage.textContent = this.updateActivePageName();

          const message = `${item.name} Page loaded successfully`;
          const status = "success";
          this.displayAlertMessage(message, status);
        };
      }
      ul.appendChild(li);
    });
    return ul;
  }

  checkActivePage(id) {
    const pageId = localStorage.getItem("pageId");
    if (pageId === id) {
      return true;
    }
  }

  updateActivePageName() {
    return this.editorManager.getCurrentPageName();
  }

  openFileUploadModal() {
    const modal = document.createElement("div");
    modal.className = "modal";

    const modalContent = document.createElement("div");
    modalContent.className = "modal-content";

    modalContent.innerHTML = `
    <div class="modal-header">
        <h2>Upload</h2>
        <span class="close">
            <svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21">
                <path id="Icon_material-close" data-name="Icon material-close" d="M28.5,9.615,26.385,7.5,18,15.885,9.615,7.5,7.5,9.615,15.885,18,7.5,26.385,9.615,28.5,18,20.115,26.385,28.5,28.5,26.385,20.115,18Z" transform="translate(-7.5 -7.5)" fill="#6a747f" opacity="0.54"/>
            </svg>
        </span>
    </div>
    <div class="upload-area" id="uploadArea">
        <svg xmlns="http://www.w3.org/2000/svg" width="40.999" height="28.865" viewBox="0 0 40.999 28.865">
            <path id="Path_1040" data-name="Path 1040" d="M21.924,11.025a3.459,3.459,0,0,0-3.287,3.608,3.459,3.459,0,0,0,3.287,3.608,3.459,3.459,0,0,0,3.287-3.608A3.459,3.459,0,0,0,21.924,11.025ZM36.716,21.849l-11.5,14.432-8.218-9.02L8.044,39.89h41Z" transform="translate(-8.044 -11.025)" fill="#afadad"/>
          </svg>
        <p>Drag and drop or <a href="#" id="browseLink">browse</a></p>
    </div>
    <div class="file-list" id="fileList"></div>
    <div class="modal-actions">
        <button class="toolbox-btn toolbox-btn-outline" id="cancelBtn">Cancel</button>
        <button class="toolbox-btn toolbox-btn-primary" id="saveBtn">Save</button>
    </div>
    `;

    modal.appendChild(modalContent);

    return modal;
  }

  handleFileManager() {
    const openModal = document.getElementById("image-bg");
    const fileInputField = document.createElement("input");
    const modal = this.openFileUploadModal();

    let selectedFile = null;
    let allUploadedFiles = [];

    openModal.addEventListener("click", (e) => {
      e.preventDefault()
      if (this.editorManager.editor.getSelected()) {
        fileInputField.type = "file";
        fileInputField.multiple = true;
        fileInputField.accept = "image/jpeg, image/jpg, image/png"; // Only accept specific image types
        fileInputField.id = "fileInput";
        fileInputField.style.display = "none";

        document.body.appendChild(modal);
        document.body.appendChild(fileInputField);

        modal.style.display = "flex";

        const uploadArea = modal.querySelector("#uploadArea");
        uploadArea.onclick = () => {
          fileInputField.click();
        };

        fileInputField.onchange = (event) => {
          // Filter only allowed image types
          const newFiles = Array.from(event.target.files).filter((file) =>
            ["image/jpeg", "image/jpg", "image/png"].includes(file.type)
          );
          allUploadedFiles = [...allUploadedFiles, ...newFiles];

          this.uploadFiles(allUploadedFiles)

          const fileList = modal.querySelector("#fileList");
          fileList.innerHTML = "";

          allUploadedFiles.forEach((file) => {
            const fileItem = document.createElement("div");
            fileItem.className = "file-item";

            const img = document.createElement("img");
            const reader = new FileReader();
            reader.onload = (e) => {
              img.src = e.target.result;
            };
            reader.readAsDataURL(file);
            img.alt = "File thumbnail";
            img.className = "preview-image";

            const fileInfo = document.createElement("div");
            fileInfo.className = "file-info";

            const fileName = document.createElement("div");
            fileName.className = "file-name";
            fileName.textContent = file.name;

            const fileSize = document.createElement("div");
            fileSize.className = "file-size";
            const formatFileSize = (bytes) => {
              if (bytes < 1024) return `${bytes} B`;
              if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
              if (bytes < 1024 * 1024 * 1024)
                return `${Math.round(bytes / 1024 / 1024)} MB`;
              return `${Math.round(bytes / 1024 / 1024 / 1024)} GB`;
            };

            fileSize.textContent = formatFileSize(file.size);

            const statusIcon = document.createElement("span");
            statusIcon.className = "status-icon";

            // Check file size limit (2MB) and file type
            const isValidSize = file.size <= 2 * 1024 * 1024;
            const isValidType = [
              "image/jpeg",
              "image/jpg",
              "image/png",
            ].includes(file.type);

            if (isValidSize && isValidType) {
              fileItem.classList.add("valid");
              statusIcon.innerHTML = "";
              statusIcon.style.color = "green";
            } else {
              fileItem.classList.add("invalid");
              statusIcon.innerHTML = "⚠";
              statusIcon.style.color = "red";
            }

            fileItem.onclick = () => {
              if (fileItem.classList.contains("invalid")) {
                return;
              }

              document.querySelector(".modal-actions").style.display = "flex";

              document.querySelectorAll(".file-item").forEach((el) => {
                el.classList.remove("selected");
                const icon = el.querySelector(".status-icon");
                if (icon) {
                  icon.innerHTML = el.classList.contains("invalid") ? "⚠" : "";
                }
              });

              fileItem.classList.add("selected");
              statusIcon.innerHTML = `
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="13.423" viewBox="0 0 18 13.423">
                          <path id="Icon_awesome-check" data-name="Icon awesome-check" d="M6.114,17.736l-5.85-5.85a.9.9,0,0,1,0-1.273L1.536,9.341a.9.9,0,0,1,1.273,0L6.75,13.282l8.441-8.441a.9.9,0,0,1,1.273,0l1.273,1.273a.9.9,0,0,1,0,1.273L7.386,17.736A.9.9,0,0,1,6.114,17.736Z" transform="translate(0 -4.577)" fill="#3a9341"/>
                        </svg>
                      `;
              statusIcon.style.color = "green";
              selectedFile = file;
            };

            fileInfo.appendChild(fileName);
            fileInfo.appendChild(fileSize);

            fileItem.appendChild(img);
            fileItem.appendChild(fileInfo);
            fileItem.appendChild(statusIcon);
            fileList.appendChild(fileItem);
          });
        };
      } else {
        const message = "Please select a tile to continue";
        const status = "error";
        this.displayAlertMessage(message, status);
      }
    });

    const closeButton = modal.querySelector(".close");
    closeButton.onclick = () => {
      modal.style.display = "none";
      document.body.removeChild(modal);
      document.body.removeChild(fileInputField);
    };

    const cancelBtn = modal.querySelector("#cancelBtn");
    cancelBtn.onclick = () => {
      modal.style.display = "none";
      document.body.removeChild(modal);
      document.body.removeChild(fileInputField);
    };

    const saveBtn = modal.querySelector("#saveBtn");
    saveBtn.onclick = () => {
      if (selectedFile) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const templateBlock = this.editorManager.editor
            .getSelected()
            .find(".template-block")[0];
          templateBlock.addStyle({
            "background-image": `url(${e.target.result})`,
            "background-size": "cover",
            "background-position": "center",
          });

          //this.setAttributeToSelected("tile-bgimage", `url(${e.target.result})`)
        };
        reader.readAsDataURL(selectedFile);
      }

      modal.style.display = "none";
      document.body.removeChild(modal);
      document.body.removeChild(fileInputField);
    };
  }

  uploadFiles (files) {
    console.log(files)
    files.forEach(file=>{
      if (file) {
        let formData = new FormData();
        formData.append('file', file); // Append the file to the FormData object
        
        // AJAX request
        $.ajax({
            url: '/upload', // Replace with your server URL
            type: 'POST',
            data: formData,
            contentType: false, // Important: prevent jQuery from processing the data
            processData: false, // Important: prevent jQuery from converting the data into a string
            success: function(response) {
                console.log('File uploaded successfully!', response);
            },
            error: function(xhr, status, error) {
                console.error('File upload failed!', error);
            }
        });
      } else {
        alert('Please select a file!');
      }
    })
  }


  popupModal() {
    const popup = document.createElement("div");
    popup.className = "popup-modal";
    popup.innerHTML = `
      <div class="popup">
        <div class="popup-header">
          <span>Confirmation</span>
          <button class="close">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 21 21">
                <path id="Icon_material-close" data-name="Icon material-close" d="M28.5,9.615,26.385,7.5,18,15.885,9.615,7.5,7.5,9.615,15.885,18,7.5,26.385,9.615,28.5,18,20.115,26.385,28.5,28.5,26.385,20.115,18Z" transform="translate(-7.5 -7.5)" fill="#6a747f" opacity="0.54"/>
            </svg>
          </button>
        </div>
        <hr>
        <div class="popup-body">
          When you continue, all the changes you have made will be cleared.
        </div>
        <div class="popup-footer">
          <button id="accept-popup" class="toolbox-btn toolbox-btn-primary">OK</button>
          <button id="close-popup" class="toolbox-btn toolbox-btn-outline">Cancel</button>
        </div>
      </div>
    `;

    return popup;
  }
  displayAlertMessage(message, status) {
    const alertContainer = document.getElementById("alerts-container");

    const alertId = Math.random().toString(10);

    const alertBox = this.alertMessage(message, status, alertId);
    alertBox.style.display = "flex";

    const closeButton = alertBox.querySelector(".alert-close-btn");
    closeButton.addEventListener("click", () => {
      this.closeAlert(alertId);
    });

    setTimeout(() => this.closeAlert(alertId), 5000);
    alertContainer.appendChild(alertBox);
  }
  alertMessage(message, status, alertId) {
    const alertBox = document.createElement("div");
    alertBox.id = alertId;
    alertBox.classList = `alert ${status == "success" ? "success" : "error"}`;
    alertBox.innerHTML = `
      <div class="alert-header">
        <strong>${status == "success" ? "Success" : "Error"}</strong>
        <span class="alert-close-btn">✖</span>
      </div> 
      <p>${message}</p>
    `;

    return alertBox;
  }

  closeAlert(alertId) {
    const alert = document.getElementById(alertId);
    if (alert) {
      alert.style.opacity = 0;
      setTimeout(() => alert.remove(), 500);
    }
  }

  setAttributeToSelected(attributeName, attributeValue){
    this.editorManager.editor.getSelected().addAttributes({[attributeName]: attributeValue})
  }
}

class PagesManager {
  constructor(editor) {
    this.editor = [];
    this.selectedPageId = null;
  }
}

class Clock {
  constructor() {
    this.updateTime();
    setInterval(() => this.updateTime(), 60000); // Update time every minute
  }

  updateTime() {
    const now = new Date();
    let hours = now.getHours();
    const minutes = now.getMinutes().toString().padStart(2, "0");
    const ampm = hours >= 12 ? "PM" : "AM";
    hours = hours % 12;
    hours = hours ? hours : 12; // Adjust hours for 12-hour format
    const timeString = `${hours}:${minutes}`;
    document.getElementById("current-time").textContent = timeString;
  }
}
